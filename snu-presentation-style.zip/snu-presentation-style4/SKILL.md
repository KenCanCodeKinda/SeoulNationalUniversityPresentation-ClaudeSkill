---
name: snu-presentation-style4
description: Create professional academic presentations following Seoul National University (SNU) design language. Use when users request presentations in this specific Korean academic style, or ask to create presentations in PowerPoint, Google Slides, or Canva with clean, professional formatting featuring navy blue accents, section numbering, and Korean academic conventions.
---

# SNU Presentation Style

Create professional academic presentations following Seoul National University's design language. This skill supports creating presentations for Microsoft PowerPoint, Google Slides, and Canva with consistent SNU branding and formatting.

## Core Design Elements

### Color Palette
- **Primary Navy**: RGB(15, 15, 112) - Used for section numbers, accent bars, and decorative elements
- **Secondary Gray**: RGB(136, 136, 136) - Used for subtle separators and secondary bars
- **Background**: White
- **Text**: Black for primary content, white for page numbers on dark backgrounds

### Typography
- **Korean text**: Use '맑은 고딕' (Malgun Gothic) font
- **English text**: Use 'Arial' font
- **Font sizes**: Maintain hierarchy with larger sizes for titles, progressively smaller for nested content

### Layout Dimensions
- **Slide size**: 16:9 widescreen (13.33" × 7.50" or 33.87cm × 19.05cm)
- **Standard PowerPoint**: Use "Widescreen (16:9)" setting

## Required Elements on Every Slide

### Bottom Bars (All Slides Except Title)
Add two horizontal bars at the bottom of each slide:

1. **Navy blue bar**: 
   - Color: RGB(15, 15, 112)
   - Position: top=7.21" (18.31cm), left=0, width=13.33" (full width), height=0.29" (0.74cm)

2. **Gray bar** (sits above the navy bar):
   - Color: RGB(136, 136, 136)
   - Position: top=7.15" (18.16cm), left=0, width=13.33" (full width), height=0.06" (0.15cm)

### Page Numbers
- Add page numbers to all slides **except the first (title) slide**
- Position: Bottom right corner, in white text
- Suggested position: approximately left=12.0", top=7.0" (adjust based on bar placement)
- Font color: White to contrast with navy blue bar

### SNU Logo (Title Slide Only)
- Place the SNU emblem on the **first slide only** in the top right corner
- Suggested position: top=0.27", left=12.01"
- Suggested size: approximately 1.04" × 1.01"
- Use the logo from `assets/snu_logo.png`

## Slide Structure

### 1. Title Slide (First Slide)
Required elements:
- **Title**: Large, prominent text in center-left
- **Presenter name**: Below title or on right side
- **Email**: Typically in format "YourEmail@snu.ac.kr"
- **Date**: In format "YYYY.MM.DD"
- **Course/Conference name**: Small text at top
- **Navy accent bar**: Vertical or horizontal decorative element on left
- **SNU Logo**: Top right corner
- **NO page number** on this slide
- **NO bottom bars** on this slide (optional: title slides may have different styling)

### 2. Section Header Slides
- Large **section number** (e.g., "01", "02", "03") on the left
  - Color: RGB(15, 15, 112)
  - Large font size (e.g., 60-80pt)
- **Section title** next to the number (e.g., "서론", "기존문헌 검토")
- Bottom bars and page number present

### 3. Research Question Slide (Optional)
- **Only create this slide if the user provides an explicit research question**
- If no research question is provided, skip this slide entirely
- When present:
  - Navy blue header bar above the research question box
  - Gray background box containing the research questions
  - Section number and title at top (same as other content slides)

### 4. Content Slides
- Section number and title at top (smaller than section headers)
- Main content area with bullet points following the nested list format (see below)
- Bottom bars and page number present

## Nested List Formatting

**CRITICAL**: Use this exact three-level bullet point hierarchy:

### Level 1 (Top Level)
- **Bullet style**: Filled square (■)
- **Font size**: Largest (e.g., 18-20pt)
- **Indentation**: No indent (flush left within content area)

### Level 2 (Second Level)
- **Bullet style**: Unfilled circle (○)
- **Font size**: Medium (e.g., 16-18pt)
- **Indentation**: Indented from level 1

### Level 3 (Third Level)
- **Bullet style**: Dash (–) or hyphen (-)
- **Font size**: Smallest (e.g., 14-16pt)
- **Indentation**: Further indented from level 2

### Example Structure:
```
■ Main point in larger text
  ○ Supporting detail in medium text
    – Sub-detail in smaller text
    – Another sub-detail in smaller text
  ○ Another supporting detail
■ Another main point
```

## Platform-Specific Implementation

### Microsoft PowerPoint (.pptx)
1. Use the provided template at `assets/template.pptx` as a starting point
2. Use `python-pptx` library for programmatic creation
3. Set slide size to Widescreen (16:9): `prs.slide_width = Inches(13.33)`, `prs.slide_height = Inches(7.5)`
4. Add shapes for bars using `slide.shapes.add_shape()` with AutoShape rectangles
5. Insert logo using `slide.shapes.add_picture()` from `assets/snu_logo.png`
6. Set fonts explicitly in each text frame:
   - Korean: `font.name = '맑은 고딕'`
   - English: `font.name = 'Arial'`
7. Create three-level bullet formatting by setting `paragraph.level` (0, 1, 2) and configuring bullet characters

### Google Slides
1. Create presentation with 16:9 aspect ratio
2. Add shapes for bottom bars (Insert → Shape → Rectangle)
3. Set exact colors using custom color picker:
   - Navy: RGB(15, 15, 112) or Hex #0F0F70
   - Gray: RGB(136, 136, 136) or Hex #888888
4. Insert logo image (Insert → Image → Upload from computer)
5. Create text boxes with appropriate fonts
6. Use Format → Text → List options to create nested bullets
7. Export as .pptx or share link when complete

### Canva
1. Start with blank presentation template (16:9)
2. Add rectangle elements for bottom bars:
   - Use color picker to input exact RGB values
3. Upload and place SNU logo from `assets/snu_logo.png`
4. Add text elements with:
   - Font selection (use closest equivalents: "Noto Sans KR" for Korean, "Arial" for English)
5. Create bullet points manually:
   - Type bullet characters: ■ (Level 1), ○ (Level 2), – (Level 3)
   - Adjust indentation manually with space or indent controls
6. Download as PowerPoint (.pptx) or PDF when complete

## Workflow

1. **Understand the content**: Clarify the presentation topic, number of sections, and key points
2. **Choose platform**: Ask user preference for PowerPoint, Google Slides, or Canva (default to PowerPoint if not specified)
3. **Structure the presentation**:
   - Title slide (no page number, with logo)
   - Section headers as needed
   - Research question slide (only if provided)
   - Content slides with properly formatted bullet points
4. **Apply formatting**:
   - Add bottom bars to all slides except title
   - Add page numbers to all slides except title
   - Use correct fonts for Korean and English text
   - Apply three-level bullet hierarchy
5. **Quality check**:
   - Verify all Korean text uses '맑은 고딕'
   - Verify all English text uses 'Arial'
   - Confirm nested bullets follow: ■ → ○ → –
   - Ensure bottom bars and page numbers are present (except title slide)
   - Verify logo appears only on title slide

## Important Notes

- **Research question slides**: Only include if user explicitly provides research questions. Do not force this slide if content doesn't require it.
- **Consistency**: Maintain visual consistency across all slides
- **Language mixing**: When slides contain both Korean and English, ensure each uses its designated font
- **Professional appearance**: Keep design clean and academic, avoiding excessive decoration
- **Spacing**: Maintain appropriate whitespace and margins for readability

## Assets

- `assets/snu_logo.png` - Seoul National University emblem for title slide
- `assets/template.pptx` - Reference template with proper formatting examples
