# SNU Presentation Style - Design Specifications

## Color Palette

### Primary Colors
- **Dark Navy Blue**: `#0e4a84` - Used for title slide branding and logo areas
- **Deep Blue**: `#0f0f70` - Used for accent elements (vertical bar on title slide, special text highlights, research question headers)
- **Medium Gray**: `#898c8e` - Used for emphasis boxes (hypotheses, key findings)

### Color Usage Guidelines
- **Title slide decorative elements**: Deep Blue (#0f0f70) for vertical bar and header text
- **Emphasis boxes (hypotheses/key findings)**: Medium Gray (#898c8e) background with white text
- **Special highlights (research questions)**: Deep Blue (#0f0f70) for text or thin horizontal bars
- **Body text**: Black or dark gray (default)

## Typography

### Primary Font
- **Korean**: Rix고딕 B (Rix Gothic B) - A clean, professional Korean Gothic font
- **English Fallback**: Use Arial, Helvetica, or similar sans-serif fonts for English content

### Font Sizes
- **Main Title (Title Slide)**: 35pt
- **Section Headers**: 22-24pt
- **Body Text**: 18-20pt
- **Emphasis Boxes (Hypotheses/Key Points)**: 16pt
- **Footnotes/Citations**: 12-14pt

### Font Styling
- Section titles: Bold
- Key phrases: Bold for emphasis
- Hypothesis boxes: Regular weight in colored background boxes

## Layout Structure

### Slide Dimensions
- **Standard**: 13.33" × 7.5" (16:9 widescreen format)

### Common Slide Layouts

#### 1. Title Slide ("1_제목만")

**Elements:**
- **Class/Conference name** (top left): Deep blue text (#0f0f70), Rix고딕 B
  - Position: (0.97", 0.57"), Size: 4.21" x 0.4"
- **Blue vertical bar** (left of title): Decorative element
  - Position: (0.79", 2.65"), Size: 0.15" x 1.12"
  - Fill: Deep blue (#0f0f70)
- **Main title**: 35pt, Rix고딕 B, centered
  - Position: (1.07", 2.43"), Size: 11.72" x 1.56"
- **Date** (top right): 22pt, format "2025.00.00"
  - Position: (9.52", 5.57"), Size: 3.01" x 0.4"
- **Author information** (bottom right): Name with degree designation
  - Position: (9.52", 4.29"), Size: 3.38" x 1.28"
  - Format: "Name(석사과정/박사과정/교수)\nAdvisor(X교수)"
- **Email** (bottom left): 15pt, Rix고딕 B
  - Position: (1.5", 4.29"), Size: 3.2" x 0.61"
  - Format: "Email: yourname@snu.ac.kr"

**Key Feature:** Blue vertical bar on left side creates visual interest and brand alignment.

#### 2. Section Header Slide ("2_구역 머리글")

**Three Placeholders:**

1. **Section Number** (텍스트 개체 틀 3) - TOP LEFT
   - Position: (0.51", 0.34")
   - Size: 0.88" x 0.71"
   - Content: Two-digit number only ("01", "02", "03", etc.)

2. **Section Title** (제목 2) - Next to number
   - Position: (1.38", 0.34")
   - Size: 11.3" x 0.65"
   - Content: Section name (e.g., "서론", "기존문헌 검토", "가설 개발")

3. **Content Area** (내용 개체 틀 1) - Main body
   - Position: (0.51", 1.28")
   - Size: 12.18" x 5.47"
   - Content: Bullet points, paragraphs, diagrams

**Layout Pattern:**
The section number and title appear side-by-side at the top of the slide, creating a clear header. The content area begins below, spanning the full width of the usable slide area.

**Note:** All three elements come from the master layout and should be used as placeholders, not manually positioned text boxes.

### Content Slide Elements

#### Emphasis/Hypothesis Boxes

**CRITICAL: Use GRAY (#898c8e), not blue.**

- **Background**: Medium Gray (#898c8e)
- **Text Color**: White (theme_BACKGROUND_1)
- **Font**: Rix고딕 B, 16pt, regular weight
- **Padding**: Adequate spacing around text
- **Shape**: Rectangle (AUTO_SHAPE)
- **Typical Position**: Bottom area of slide, e.g., (2.04", 5.89")
- **Typical Size**: 9.11" x 0.95"
- **Usage**: Highlight hypotheses (H1a, H1b, etc.), key findings, important conclusions

**Example Content:**
```
H1a: 녹색 기술준비성은 기업의 환경성과에 긍정적 영향을 미칠 것이다.
H1b: 녹색 기술준비성은 기업의 경쟁성과에 긍정적 영향을 미칠 것이다.
```

#### Bullet Points and Lists
- Use clear hierarchy with proper indentation
- Maintain consistent spacing
- Align with Korean typography standards

## Section Numbering System

### Format
- Use two-digit numbers: "01", "02", "03", etc.
- Numbers are displayed as HEADING IDENTIFIERS in a dedicated placeholder
- Position: TOP LEFT corner at (0.51", 0.34")
- Size: 0.88" x 0.71"
- The number identifies which section the slide belongs to

### Visual Implementation
- **Number Placeholder**: Top left corner position (0.51", 0.34")
- **Title Placeholder**: Immediately to the right at (1.38", 0.34")
- **Layout**: Number and title appear side-by-side at the top
- **Persistent**: Same number appears on ALL slides within that section

### Common Section Sequence
The numbers correspond to these standard academic sections:

1. **01** → 서론 (Introduction)
2. **02** → 기존문헌 검토 (Literature Review)
3. **03** → 가설 개발 (Hypothesis Development)
4. **04** → 방법론 (Methodology)
5. **05** → 실증분석 (Empirical Analysis)
6. **06** → 결론 및 토의 (Conclusion & Discussion)

### Layout Example
```
  01   Introduction                      ← Both at y=0.34"
  ────────────────────────────────────
  
  Content area begins here...           ← At y=1.28"
```

**Usage:** All Introduction slides display "01" in top left; Literature Review slides display "02", etc.

## Platform-Specific Guidelines

### Microsoft PowerPoint
- Use theme colors for consistency
- Apply master slide layouts
- Utilize placeholders for structured content
- Font embedding: Ensure Rix고딕 B or fallback fonts are available

### Google Slides
- Import custom colors as theme colors
- Use layout templates
- Note: Rix고딕 B may not be available; use Noto Sans KR or similar Korean font
- Alternative fonts: Nanum Gothic, Noto Sans KR

### Canva
- Create brand kit with SNU color palette
- Set up font pairings (Rix고딕 B equivalent or closest Korean Gothic font)
- Use frames for consistent positioning
- Template elements as components for reusability

## Design Principles

### Academic Professionalism
- Clean, uncluttered layouts
- Emphasis on content over decoration
- Consistent alignment and spacing
- Professional color usage

### Information Hierarchy
- Clear visual hierarchy with size and weight
- Section numbers for navigation
- Highlighted boxes for key information
- Adequate white space

### Accessibility
- High contrast between text and backgrounds
- Readable font sizes (minimum 16pt for body text)
- Clear section organization
- Consistent layout patterns
