# SNU Presentation Style - Design Specifications

## Color Palette

### Primary Colors
- **Dark Navy Blue**: `#0e4a84` - Used for main headers, section numbers, and primary branding elements
- **Deep Blue**: `#0f0f70` - Used for emphasis boxes, key content highlights, and accented text
- **Medium Gray**: `#898c8e` - Used for secondary text and subtle elements

### Color Usage Guidelines
- Headers and section titles: Dark Navy Blue (#0e4a84)
- Hypothesis/key point boxes: Deep Blue (#0f0f70) background with white or light text
- Body text: Black or dark gray
- Secondary information: Medium Gray (#898c8e)

## Typography

### Primary Font
- **Korean**: Rix고딕 B (Rix Gothic B) - A clean, professional Korean Gothic font
- **English Fallback**: Use Arial, Helvetica, or similar sans-serif fonts for English content

### Font Sizes
- **Main Title (Title Slide)**: 35pt
- **Section Headers**: 22-24pt
- **Body Text**: 18-20pt
- **Emphasis Boxes (Hypotheses/Key Points)**: 16pt
- **Footnotes/Citations**: 12-14pt

### Font Styling
- Section titles: Bold
- Key phrases: Bold for emphasis
- Hypothesis boxes: Regular weight in colored background boxes

## Layout Structure

### Slide Dimensions
- **Standard**: 13.33" × 7.5" (16:9 widescreen format)

### Common Slide Layouts

#### 1. Title Slide ("1_제목만")
**Elements:**
- Date (top area): 22pt, right-aligned or centered
- Main title: 35pt, Rix고딕 B, centered or left-aligned
- Author information: Includes name with degree (석사과정/박사과정/교수 etc.), bold
- Optional text box with blue accent color (#0f0f70)

**Positioning:**
- Title: Centered vertically and horizontally
- Author: Below title, smaller font
- Date: Top right or top area

#### 2. Section Header Slide ("2_구역 머리글")
**Elements:**
- Section number: Large format (e.g., "01", "02", "03")
- Section title: Aligned with number
- Content area: Main body text

**Positioning:**
- Section number: Top right corner or designated area
- Section title: Adjacent to section number
- Content: Main area of slide

### Content Slide Elements

#### Emphasis/Hypothesis Boxes
- **Background**: Deep Blue (#0f0f70)
- **Text Color**: White or very light color (theme_BACKGROUND_1)
- **Font**: Rix고딕 B, 16pt
- **Padding**: Adequate spacing around text
- **Shape**: Rectangle with slight rounding (auto-shape)
- **Usage**: Highlight hypotheses, research questions, key findings

#### Bullet Points and Lists
- Use clear hierarchy with proper indentation
- Maintain consistent spacing
- Align with Korean typography standards

## Section Numbering System

### Format
- Use two-digit numbers: "01", "02", "03", etc.
- Numbers are displayed as HEADING IDENTIFIERS, not decorative elements
- Each number appears in a dark blue box in the top-right area of slides
- The number identifies which section the slide belongs to

### Visual Implementation
- **Number Box**: Dark blue square (#0e4a84) in top-right corner
- **Number Text**: White, centered in box
- **Persistent**: Same number appears on ALL slides within that section

### Common Section Sequence
The numbers correspond to these standard academic sections:

1. **01** → 서론 (Introduction)
2. **02** → 기존문헌 검토 (Literature Review)
3. **03** → 가설 개발 (Hypothesis Development)
4. **04** → 방법론 (Methodology)
5. **05** → 실증분석 (Empirical Analysis)
6. **06** → 결론 및 토의 (Conclusion & Discussion)

**Usage Example:**
- All Introduction slides display "01" in top-right
- When Literature Review begins, slides display "02"
- Methodology section slides all show "04"

## Platform-Specific Guidelines

### Microsoft PowerPoint
- Use theme colors for consistency
- Apply master slide layouts
- Utilize placeholders for structured content
- Font embedding: Ensure Rix고딕 B or fallback fonts are available

### Google Slides
- Import custom colors as theme colors
- Use layout templates
- Note: Rix고딕 B may not be available; use Noto Sans KR or similar Korean font
- Alternative fonts: Nanum Gothic, Noto Sans KR

### Canva
- Create brand kit with SNU color palette
- Set up font pairings (Rix고딕 B equivalent or closest Korean Gothic font)
- Use frames for consistent positioning
- Template elements as components for reusability

## Design Principles

### Academic Professionalism
- Clean, uncluttered layouts
- Emphasis on content over decoration
- Consistent alignment and spacing
- Professional color usage

### Information Hierarchy
- Clear visual hierarchy with size and weight
- Section numbers for navigation
- Highlighted boxes for key information
- Adequate white space

### Accessibility
- High contrast between text and backgrounds
- Readable font sizes (minimum 16pt for body text)
- Clear section organization
- Consistent layout patterns
