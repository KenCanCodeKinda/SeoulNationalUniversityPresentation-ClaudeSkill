---
name: snu-presentation-style
description: Create professional academic presentations following Seoul National University (SNU) design language. Use when users request presentations in this specific Korean academic style, or ask to create presentations in PowerPoint, Google Slides, or Canva with clean, professional formatting featuring navy blue accents, section numbering, and Korean academic conventions.
---

# SNU Presentation Style

## Overview

This skill enables creation of professional academic presentations following the Seoul National University design language. The style features clean layouts with navy blue accents (#0e4a84, #0f0f70), section-based organization with two-digit numbering (01, 02, 03...), and Korean academic formatting conventions. Suitable for research presentations, academic reports, and professional Korean-language content.

## When to Use This Skill

Trigger this skill when users request:
- Presentations in SNU style or Korean academic format
- Professional presentations with section numbering and clean design
- PowerPoint, Google Slides, or Canva presentations with specific Korean formatting
- Academic presentations with hypothesis boxes and structured layouts

## Platform Selection

### Determine Target Platform

Ask the user which platform they prefer if not specified:
- **Microsoft PowerPoint**: Full template support, best for .pptx files
- **Google Slides**: Cloud-based, requires font substitutions
- **Canva**: Design-focused, requires manual color setup

### Platform-Specific Considerations

**PowerPoint:**
- Use python-pptx library for programmatic creation
- Copy and modify template from `assets/snu_template.pptx`
- Apply theme colors and master layouts

**Google Slides:**
- Font substitution: Use Noto Sans KR or Nanum Gothic instead of Rix고딕 B
- Create slides with custom color themes
- Manual layout positioning required

**Canva:**
- Describe design elements for manual creation
- Provide color codes and font specifications
- Suggest layout structures

## Core Design Elements

### Color Palette
- **Dark Navy Blue**: `#0e4a84` (headers, section numbers, primary elements)
- **Deep Blue**: `#0f0f70` (emphasis boxes, highlighted content)
- **Medium Gray**: `#898c8e` (secondary text)

### Typography
- **Primary Font**: Rix고딕 B (Korean Gothic)
- **English Fallback**: Arial or Helvetica
- **Title Size**: 35pt
- **Section Headers**: 22-24pt
- **Body Text**: 18-20pt
- **Emphasis Boxes**: 16pt

### Section Numbering
Use two-digit format: 01, 02, 03, etc.

Common sections:
- 01 - 서론 (Introduction)
- 02 - 기존문헌 검토 (Literature Review)
- 03 - 가설 개발 (Hypothesis Development)
- 04 - 방법론 (Methodology)
- 05 - 실증분석 (Empirical Analysis)
- 06 - 결론 및 토의 (Conclusion & Discussion)

## Creating Presentations

### Workflow Decision Tree

1. **Determine platform** → PowerPoint, Google Slides, or Canva
2. **Choose approach**:
   - **Template-based** (PowerPoint): Copy and modify `assets/snu_template.pptx`
   - **Programmatic** (PowerPoint): Use python-pptx with design specifications
   - **Manual guidance** (Google Slides/Canva): Provide detailed instructions
3. **Read design specifications** → `references/design_specifications.md` for detailed specs
4. **Create slides** → Apply design language consistently

### For PowerPoint (.pptx)

#### Option 1: Template-Based Approach
```python
from pptx import Presentation
from shutil import copy

# Copy template
copy('assets/snu_template.pptx', '/home/claude/presentation.pptx')

# Open and modify
prs = Presentation('/home/claude/presentation.pptx')

# Add slides using template layouts
# Layout 0: Title slide (1_제목만)
# Layout 1: Section header (2_구역 머리글)

title_slide = prs.slides.add_slide(prs.slide_layouts[0])
# Modify placeholders with user content
```

#### Option 2: Programmatic Creation
Read `references/design_specifications.md` for complete color and typography specs, then create slides from scratch with python-pptx.

### For Google Slides

Provide step-by-step instructions with:
- Exact color codes (#0e4a84, #0f0f70, #898c8e)
- Font recommendations (Noto Sans KR or Nanum Gothic)
- Layout positioning guidelines
- Section numbering format

### For Canva

Describe design elements:
- Color palette setup in brand kit
- Font pairings and sizes
- Layout structure with measurements
- Component creation for reusable elements

## Key Design Patterns

### Title Slide
- Date: Top area, 22pt
- Main title: 35pt, Rix고딕 B, centered
- Author: Name with degree designation (석사과정/박사과정/교수)
- Optional: Blue accent text box (#0f0f70)

### Content Slides
- Section number: Top right, two-digit format
- Section title: Adjacent to number
- Body content: 18-20pt, clear hierarchy
- Emphasis boxes: Deep blue background (#0f0f70), white text, 16pt

### Emphasis Boxes (Hypotheses/Key Points)
Create blue boxes for:
- Research hypotheses (H1a, H1b, etc.)
- Research questions
- Key findings
- Important takeaways

**Format:**
- Background: #0f0f70
- Text: White or very light
- Font: 16pt, regular weight
- Shape: Rounded rectangle

## Quality Checklist

Before finalizing, verify:
- [ ] Consistent color usage (navy blues and gray)
- [ ] Section numbering present and correct (01, 02, etc.)
- [ ] Font sizes appropriate (35pt titles, 18-20pt body)
- [ ] Emphasis boxes properly formatted
- [ ] Korean fonts (Rix고딕 B or substitute) applied
- [ ] Clean, professional layout with adequate white space
- [ ] High contrast for readability
- [ ] Slide dimensions: 16:9 widescreen (13.33" × 7.5")

## Resources

### references/design_specifications.md
Comprehensive design specifications including:
- Complete color palette with usage guidelines
- Typography details (fonts, sizes, styling)
- Layout structures for different slide types
- Platform-specific guidelines
- Design principles and accessibility standards

**When to read:** Before creating any presentation to ensure accurate adherence to design language.

### assets/snu_template.pptx
Original SNU presentation template with all layouts and design elements.

**When to use:** As source template for PowerPoint-based presentations or reference for design patterns.
