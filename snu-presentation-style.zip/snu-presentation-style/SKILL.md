---
name: snu-presentation-style
description: Create professional academic presentations following Seoul National University (SNU) design language. Use when users request presentations in this specific Korean academic style, or ask to create presentations in PowerPoint, Google Slides, or Canva with clean, professional formatting featuring navy blue accents, section numbering, and Korean academic conventions.
---

# SNU Presentation Style

## Overview

This skill enables creation of professional academic presentations following the Seoul National University design language. The style features clean layouts with navy blue accents (#0e4a84, #0f0f70), section-based organization with two-digit numbering (01, 02, 03...), and Korean academic formatting conventions. Suitable for research presentations, academic reports, and professional Korean-language content.

## When to Use This Skill

Trigger this skill when users request:
- Presentations in SNU style or Korean academic format
- Professional presentations with section numbering and clean design
- PowerPoint, Google Slides, or Canva presentations with specific Korean formatting
- Academic presentations with hypothesis boxes and structured layouts

## Platform Selection

### Determine Target Platform

Ask the user which platform they prefer if not specified:
- **Microsoft PowerPoint**: Full template support, best for .pptx files
- **Google Slides**: Cloud-based, requires font substitutions
- **Canva**: Design-focused, requires manual color setup

### Platform-Specific Considerations

**PowerPoint:**
- Use python-pptx library for programmatic creation
- Copy and modify template from `assets/snu_template.pptx`
- Apply theme colors and master layouts

**Google Slides:**
- Font substitution: Use Noto Sans KR or Nanum Gothic instead of Rix고딕 B
- Create slides with custom color themes
- Manual layout positioning required

**Canva:**
- Describe design elements for manual creation
- Provide color codes and font specifications
- Suggest layout structures

## Core Design Elements

### Color Palette
- **Dark Navy Blue**: `#0e4a84` (title slide header elements, logo area)
- **Deep Blue**: `#0f0f70` (accent elements, vertical bar on title slide, special emphasis text)
- **Medium Gray**: `#898c8e` (hypothesis boxes, key finding boxes)

### Color Usage
- **Title slide accents**: Deep blue (#0f0f70) for vertical bar and header text
- **Emphasis boxes (hypotheses/key findings)**: Medium gray (#898c8e) background with white text
- **Body text**: Black
- **Section structure**: Use template's default colors from placeholders

### Typography
- **Primary Font**: Rix고딕 B (Korean Gothic)
- **English Fallback**: Arial or Helvetica
- **Title Size**: 35pt
- **Section Headers**: 22-24pt
- **Body Text**: 18-20pt
- **Emphasis Boxes**: 16pt

### Section Numbering System

**CRITICAL: Section numbers appear in TOP LEFT corner, not top right.**

Each major section has a two-digit number (01, 02, 03...) displayed as a separate element:

**Position:** Top left corner at approximately (0.51", 0.34")
**Size:** Small box, approximately 0.88" x 0.71"
**Format:** Just the number: "01", "02", "03" (no additional text)

**Layout Pattern:**
```
┌─────────────────────────────────────────┐
│  01   Introduction                      │  ← Number (left) + Section title (next to it)
│  ──────────────────────────────────────  │
│                                          │
│  • Content...                            │
│                                          │
└─────────────────────────────────────────┘
```

**Key Details:**
- Section number box: Position (0.51", 0.34"), size 0.88" x 0.71"
- Section title: Position (1.38", 0.34"), size 11.3" x 0.65"
- They are SEPARATE placeholders, side by side at the top
- Both appear on the same horizontal line
- Number stays consistent for all slides in that section

**Common Academic Section Sequence:**
- **01** → 서론 (Introduction)
- **02** → 기존문헌 검토 (Literature Review)
- **03** → 가설 개발 (Hypothesis Development)
- **04** → 방법론 (Methodology)
- **05** → 실증분석 (Empirical Analysis)
- **06** → 결론 및 토의 (Conclusion & Discussion)

**Implementation:**
- Use slide layout "2_구역 머리글"
- First placeholder (0.51", 0.34"): Section number only
- Second placeholder (1.38", 0.34"): Section title only
- Third placeholder (0.51", 1.28"): Main content area

## Creating Presentations

### Workflow Decision Tree

1. **Determine platform** → PowerPoint, Google Slides, or Canva
2. **Choose approach**:
   - **Template-based** (PowerPoint): Copy and modify `assets/snu_template.pptx`
   - **Programmatic** (PowerPoint): Use python-pptx with design specifications
   - **Manual guidance** (Google Slides/Canva): Provide detailed instructions
3. **Read design specifications** → `references/design_specifications.md` for detailed specs
4. **Create slides** → Apply design language consistently

### For PowerPoint (.pptx)

#### Option 1: Template-Based Approach
```python
from pptx import Presentation
from shutil import copy

# Copy template
copy('assets/snu_template.pptx', '/home/claude/presentation.pptx')

# Open and modify
prs = Presentation('/home/claude/presentation.pptx')

# Add slides using template layouts
# Layout 0: Title slide (1_제목만)
# Layout 1: Section header (2_구역 머리글)

title_slide = prs.slides.add_slide(prs.slide_layouts[0])
# Modify placeholders with user content
```

#### Option 2: Programmatic Creation
Read `references/design_specifications.md` for complete color and typography specs, then create slides from scratch with python-pptx.

### For Google Slides

Provide step-by-step instructions with:
- Exact color codes (#0e4a84, #0f0f70, #898c8e)
- Font recommendations (Noto Sans KR or Nanum Gothic)
- Layout positioning guidelines
- Section numbering format

### For Canva

Describe design elements:
- Color palette setup in brand kit
- Font pairings and sizes
- Layout structure with measurements
- Component creation for reusable elements

## Key Design Patterns

### Title Slide ("1_제목만")

**Layout Structure:**
```
┌─────────────────────────────────────────┐
│ Class/Conference Name            Date   │  ← Top area
│ █                                        │  ← Blue vertical bar
│ │                                        │
│ │  Main Presentation Title               │  ← Centered title area
│ │                                        │
│     Email: you@snu.ac.kr          Author│  ← Bottom area
│                                    Info  │
└─────────────────────────────────────────┘
```

**Key Elements:**

1. **Class/Conference Text Box** (Top Left)
   - Position: (0.97", 0.57")
   - Size: 4.21" x 0.4"
   - Font: Rix고딕 B
   - Color: Deep blue (#0f0f70)
   - Content: "Name of Class or Conference Here"

2. **Blue Vertical Bar** (Left Side)
   - Position: (0.79", 2.65")
   - Size: 0.15" x 1.12"
   - Fill color: Deep blue (#0f0f70)
   - Decorative element next to title

3. **Main Title** (Placeholder)
   - Position: (1.07", 2.43")
   - Size: 11.72" x 1.56"
   - Font: Rix고딕 B, 35pt
   - Content: Presentation title

4. **Date** (Placeholder - Top Right)
   - Position: (9.52", 5.57")
   - Size: 3.01" x 0.4"
   - Font: 22pt
   - Format: "2025.00.00"

5. **Author Information** (Placeholder - Bottom Right)
   - Position: (9.52", 4.29")
   - Size: 3.38" x 1.28"
   - Content: Name with degree designation
   - Example: "김동현(석사과정)\n000(X교수)"

6. **Email** (Text Box - Bottom Left)
   - Position: (1.5", 4.29")
   - Size: 3.2" x 0.61"
   - Font: Rix고딕 B, 15pt
   - Format: "Email: YourEmail@snu.ac.kr"

### Content Slides (Section Header Slides)

**Slide Layout: "2_구역 머리글"**

This is the main content layout with three placeholders:

```
Position Layout:
┌─────────────────────────────────────────┐
│  01   Introduction                      │  ← Top row at y=0.34"
│  ──────────────────────────────────────  │
│                                          │
│  • Main content area                     │  ← Content at y=1.28"
│  • Bullet points                         │
│  • Text and diagrams                     │
│                                          │
└─────────────────────────────────────────┘
```

**Three Placeholders:**

1. **Section Number** (텍스트 개체 틀 3)
   - Position: (0.51", 0.34")
   - Size: 0.88" x 0.71"
   - Content: Just the number "01", "02", "03", etc.

2. **Section Title** (제목 2)
   - Position: (1.38", 0.34")
   - Size: 11.3" x 0.65"
   - Content: Section name like "서론", "기존문헌 검토", "가설 개발"

3. **Content Area** (내용 개체 틀 1)
   - Position: (0.51", 1.28")
   - Size: 12.18" x 5.47"
   - Content: Main slide content, bullet points, text

**Important:** All three are separate placeholders that come from the master layout.

### Special Slide Variations

**Research Question Slides:**
Some content slides feature a blue horizontal bar for emphasis:
- **Blue bar** position: (0.51", 1.3")
- **Blue bar** size: 12.18" x 0.14"
- **Blue bar** color: #0f0f70 (deep blue)
- Text box below with blue text (#0f0f70), 20pt
- Used for highlighting research questions or key objectives

**Example:**
```
  01   Introduction
  ──────────────────────────────────  ← Blue horizontal bar
  Research question                    ← Blue text
  - Question 1...
  - Question 2...
```

### Emphasis Boxes (Hypotheses/Key Points)

**CRITICAL: Use GRAY (#898c8e), not blue, for emphasis boxes.**

Create gray boxes for:
- Research hypotheses (H1a, H1b, H2a, H2b, etc.)
- Key findings
- Important takeaways

**Specifications:**
- **Background Color**: #898c8e (medium gray)
- **Text Color**: White (theme_BACKGROUND_1)
- **Font**: Rix고딕 B, 16pt, regular weight
- **Shape**: Rectangle (AUTO_SHAPE type)
- **Typical Position**: (2.04", 5.89") - bottom area of slide
- **Typical Size**: 9.11" x 0.95"

**Usage Pattern:**
```python
# When creating hypothesis boxes programmatically:
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE

shape = slide.shapes.add_shape(
    MSO_SHAPE.RECTANGLE,
    Inches(2.04), Inches(5.89),  # Position
    Inches(9.11), Inches(0.95)    # Size
)
shape.fill.solid()
shape.fill.fore_color.rgb = RGBColor(0x89, 0x8c, 0x8e)  # Gray
shape.line.fill.background()

# Add text
text_frame = shape.text_frame
text_frame.text = "H1a: Your hypothesis here"
paragraph = text_frame.paragraphs[0]
run = paragraph.runs[0]
run.font.name = 'Rix고딕 B'
run.font.size = Pt(16)
run.font.color.theme_color = MSO_THEME_COLOR.BACKGROUND_1  # White
```

## Quality Checklist

Before finalizing, verify:
- [ ] Consistent color usage (navy blues and gray)
- [ ] Section numbering present and correct (01, 02, etc.)
- [ ] Font sizes appropriate (35pt titles, 18-20pt body)
- [ ] Emphasis boxes properly formatted
- [ ] Korean fonts (Rix고딕 B or substitute) applied
- [ ] Clean, professional layout with adequate white space
- [ ] High contrast for readability
- [ ] Slide dimensions: 16:9 widescreen (13.33" × 7.5")

## Resources

### references/design_specifications.md
Comprehensive design specifications including:
- Complete color palette with usage guidelines
- Typography details (fonts, sizes, styling)
- Layout structures for different slide types
- Platform-specific guidelines
- Design principles and accessibility standards

**When to read:** Before creating any presentation to ensure accurate adherence to design language.

### assets/snu_template.pptx
Original SNU presentation template with all layouts and design elements.

**When to use:** As source template for PowerPoint-based presentations or reference for design patterns.
